interface StateHeatmapProps {
  data: Array<{ state_name: string; value: number; label?: string }>;
  title?: string;
}

function intensity(value: number, max: number): string {
  if (max === 0) return "bg-slate-100";
  const pct = value / max;
  if (pct > 0.75) return "bg-red-500 text-white";
  if (pct > 0.5) return "bg-orange-400 text-white";
  if (pct > 0.25) return "bg-amber-300";
  return "bg-emerald-100";
}

export function StateHeatmap({ data, title = "State Heatmap" }: StateHeatmapProps) {
  const max = Math.max(...data.map((d) => d.value), 1);
  const sorted = [...data].sort((a, b) => b.value - a.value);

  return (
    <div className="rounded-xl border-2 border-black/20 bg-card p-5">
      <h3 className="text-base font-bold mb-4">{title}</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
        {sorted.map((d) => (
          <div
            key={d.state_name}
            className={`rounded-lg px-3 py-2 border border-black/10 ${intensity(d.value, max)}`}
          >
            <p className="text-[11px] font-medium truncate">{d.state_name}</p>
            <p className="text-sm font-bold">{d.label ?? d.value}</p>
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2 mt-4 text-[10px] text-muted-foreground">
        <span>Low</span>
        <div className="flex-1 h-2 rounded-full bg-gradient-to-r from-emerald-100 via-amber-300 via-orange-400 to-red-500" />
        <span>High</span>
      </div>
    </div>
  );
}
